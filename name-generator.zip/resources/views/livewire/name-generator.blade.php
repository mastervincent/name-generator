<div class="text-center">

    <div class="bg-warning rounded p-3">
       <h1 class="p-3" style="border: 5px dashed #fff;">{{ $name }}</h1>
    </div>

    <button wire:click="generate" class="btn btn-warning btn-lg text-white my-5">
        Generate Name
    </button>

</div>